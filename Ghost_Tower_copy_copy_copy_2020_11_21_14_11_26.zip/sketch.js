var backGround , backGroundrunning , ghost , ghostMoving , doors ,movingDoors, climbers , movingClimbers;





function preload(){
backGroundrunning  =  loadImage("tower.png");
ghostMoving = loadImage("ghost-standing.png");
movingDoors = loadImage()or


}

function setup(){
createCanvas(600,600);

backGround=createSprite(300,300,20,20);
backGround.addImage(backGroundrunning);
backGround.velocityY=3

ghost=createSprite(300,500,20,20);
ghost.addImage(ghostMoving);
ghost.scale=0.3



}
function draw(){


background("black");

if(backGround.y>600){

backGround.y = 300;
}
if (keyDown("space")){
ghost.velocityY=-3

}

if(keyDown("RIGHT_ARROW")){

ghost.x=ghost.x+3;



}

if(keyDown("LEFT_ARROW")){



ghost.x=ghost.x-3;

}



ghost.velocityY=ghost.velocityY+0.8




drawSprites();
}